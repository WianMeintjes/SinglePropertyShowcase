import React from 'react';

function Features() {
  return (
    <section id="features">
      <h2 className='featuresh2'>Features & Amenities</h2>
      <ul className="features-list">
        {/* List of 12 random amenities */}
        <li>Prime Location</li>
        <li>Modern Design</li>
        <li>Apartment Features</li>
        
        </ul><ul className="features-list">
        <li>Luxurious Amenities</li>
        <li>Tech and Connectivity</li>
        <li>Parking and Accessibility</li>
        <li>Community Facilities</li>
        
        </ul><ul className="features-list">
        <li>Abundance of Entertainment Options</li>
        <li>Environmental Sustainability</li>
        <li>Management and Services</li>
       
      </ul>
    </section>
  );
}

export default Features;
