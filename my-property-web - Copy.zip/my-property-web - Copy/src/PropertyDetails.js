import React from 'react';
import './App.css'; // Import the CSS file for styling

function PropertyDetails() {
  return (
    <section id="overview" className="PropertyDetailsSection">
      <div className="details">
        <h2 className='proph2'>$2500p/n</h2>
        <div className="detail-item" id='first-item'>
          <i className="fas fa-bed"></i>
          <p>2 Bedrooms</p>
        </div>
        <div className="detail-item">
          <i className="fas fa-bath"></i>
          <p>2 Bathrooms</p>
        </div>
        <div className="detail-item">
          <i className="fas fa-ruler"></i>
          <p>110.6 sq/m.</p>
        </div>
        <div className="detail-item">
          <i className="fas fa-map"></i>
          <p>0.5 acres</p>
        </div>
      </div>
    </section>
  );
}

export default PropertyDetails;
