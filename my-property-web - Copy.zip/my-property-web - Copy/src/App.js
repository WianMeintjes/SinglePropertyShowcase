import React from 'react';
import './App.css';
import Contact from './Contact';
import Description from './Description';
import Features from './Features';
import Header from './Header';
import PhotoGallery from './PhotoGallery';
import PropertyDetails from './PropertyDetails';

function App() {
  return (
    <div className="App">
      <header>
        <Header />
      </header>
      <main>
      <section className='PropertyDetailsSection'><PropertyDetails /></section>
      <section id='description'><Description /></section>
      <section className='FeaturesSection' id='features'><Features /></section>
      <section id='photos'><PhotoGallery /></section>
      <section className='ContactSection' id='contact'><Contact /></section>
      </main>
      {/* Footer section */}
    </div>
  );
}

export default App;
