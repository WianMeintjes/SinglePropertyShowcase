import React from 'react';
import './App.css'; // Import the CSS file for styling
import Bath1 from './images/Bath1.jpeg';
import desk from './images/Desk.jpeg';
import living1 from './images/living1.jpeg';

function Description() {
  return (
    <section id="description" className='descriptionSection'>
      <div className="description-content">
        <div className="image-section">
          <img src={living1} alt="Living Room" />
        </div>
        <div className="text-section">
          <p>
            A sleek modern house boasts clean lines, expansive windows, and an
            open-concept design that blends indoor and outdoor spaces. Its
            minimalist aesthetic features a fusion of materials like concrete,
            steel, and glass, creating an inviting yet sophisticated ambiance.
            Smart home technology seamlessly integrates into the architecture,
            offering convenience and efficiency. High ceilings and natural
            light amplify the sense of space while curated furnishings and
            state-of-the-art amenities reflect a contemporary lifestyle,
            culminating in a harmonious blend of form, function, and style.
          </p>
        </div>
      </div>

      <div className="two-images-section">
        <div className="two-images-wrapper">
          <img src={Bath1} alt="Bathroom" className='img1'/>
          <img src={desk} alt="desk" className='img2'/>
        </div>
      </div>
    </section>
  );
}

export default Description;
