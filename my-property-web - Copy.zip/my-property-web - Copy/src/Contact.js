import React from 'react';

function Contact() {
  return (
    <section id="contact">
      <h2 className='contacth2'>Contact Details</h2>
      <div className="contact-info">
        <p>Ricky Phone: +123456789</p>
        <p>Mandy Phone: +987654321</p>
        <p>Email: example@example.com</p>
        <p>Landline: 012-3456789</p>
      </div>
    </section>
  );
}

export default Contact;
