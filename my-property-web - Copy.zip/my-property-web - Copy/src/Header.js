import React, { useEffect, useState } from 'react';
import './Header.css'; // Import the CSS file for styling
import Navbar from './Navbar'; // Import the Navbar component

function Header() {
  const [currentImage, setCurrentImage] = useState(0);
  const imagePaths = [
    './images/TSNT.jpg',
    './images/Bed10.jpeg',
    './images/living1.jpeg',
    './images/Bath22.jpeg',
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImage((prevImage) => (prevImage + 1) % imagePaths.length);
    }, 9500);

    return () => clearInterval(interval);
  }, [imagePaths.length]);

  return (
    <header className="main-header">
      <div className="header-container">
        {/* Background Image */}
        {imagePaths.map((image, index) => (
          <img
            key={index}
            src={image}
            alt={`Slide ${index}`}
            className={index === currentImage ? 'active' : 'inactive'}
          />
        ))}
        {/* Title and Navbar */}
        <div className="header-content">
          <h1 className="header-title">Title</h1>
          <Navbar />
        </div>
      </div>
    </header>
  );
}

export default Header;
