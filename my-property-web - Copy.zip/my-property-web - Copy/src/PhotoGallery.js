import React from 'react';
import './PhotoGallery.css'; // Import the CSS file for styling
import Aerial from './images/Aerial.jpeg'; /*Used this image in R1*/
import Balcony from './images/Balcony.jpeg'; /*Used this image in R1*/
import Bath1 from './images/Bath1.jpeg'; /*Used this image in R1*/
import Bath21 from './images/Bath21.jpeg';
import Bath22 from './images/Bath22.jpeg';
import Bed20 from './images/Bed20.jpeg';
import Bed21 from './images/Bed21.jpeg'; /*Used this image in R1*/
import Bed22 from './images/Bed22.jpeg';
import Desk from './images/Desk.jpeg'; /*Used this image in R1*/
import Kitchen from './images/Kitchen.jpeg'; /*Used this image in R1*/
import Kitchen2 from './images/Kitchen2.jpeg'; /*Going to be 1 of the Main images*/
import Kitchen3 from './images/Kitchen3.jpeg'; /*Used this image in R1*/
import living2 from './images/living2.jpeg';
import living3 from './images/living3.jpeg';

function PhotoGallery() {
  return (
    <section id="photos">
      <div className="photo-gallery">
        <div className="gallery-container">
          <div className="gallery-row">
            {/* Repeat this structure for multiple images */}
            <img src={Bed21} alt="Bed21" />
            <img src={Bath1} alt="Bath1" />
            <img src={Kitchen} alt="Kitchen" />
            <img src={Kitchen3} alt="Kitchen3" />
            <img src={Desk} alt="Desk" />
            <img src={Aerial} alt="Aerial" />
            <img src={Balcony} alt="Balcony" />
            {/* Add more images */}
            {/* Clone the images to create a loop */}
            <img src={Bed21} alt="Bed21" />
            <img src={Bath1} alt="Bath1" />
            <img src={Kitchen} alt="Kitchen" />
            <img src={Kitchen3} alt="Kitchen3" />
            <img src={Desk} alt="Desk" />
            <img src={Aerial} alt="Aerial" />
            <img src={Balcony} alt="Balcony" />
            {/* Add more images */}
            {/* Clone the images to create a loop */}
            <img src={Bed21} alt="Bed21" />
            <img src={Bath1} alt="Bath1" />
            <img src={Kitchen} alt="Kitchen" />
            <img src={Kitchen3} alt="Kitchen3" />
            <img src={Desk} alt="Desk" />
            <img src={Aerial} alt="Aerial" />
            <img src={Balcony} alt="Balcony" />
            {/* Add more images */}
            {/* Clone the images to create a loop */}
            <img src={Bed21} alt="Bed21" />
            <img src={Bath1} alt="Bath1" />
            <img src={Kitchen} alt="Kitchen" />
            <img src={Kitchen3} alt="Kitchen3" />
            <img src={Desk} alt="Desk" />
            <img src={Aerial} alt="Aerial" />
            <img src={Balcony} alt="Balcony" />
          </div>
          {/* Second row */}
          <div className="gallery-row reverse-animation">
            {/* Reverse the order of images or use the same images */}
            <img src={living2} alt="7" />
            <img src={living3} alt="7" />
            <img src={Kitchen2} alt="7" />
            <img src={Bed22} alt="5" />
            <img src={Bed20} alt="4" />
            <img src={Bath21} alt="3" />
            <img src={Bath22} alt="2" />
            {/* Clone the images to create a loop */}
            <img src={living2} alt="7" />
            <img src={living3} alt="7" />
            <img src={Kitchen2} alt="7" />
            <img src={Bed22} alt="5" />
            <img src={Bed20} alt="4" />
            <img src={Bath21} alt="3" />
            <img src={Bath22} alt="2" />
          </div>
        </div>
      </div>
    </section>
  );
}

export default PhotoGallery;